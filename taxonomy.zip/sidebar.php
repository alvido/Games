<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package juegos
 */

if (!is_active_sidebar('sidebar')) {
    return;
}

function display_game_categories_with_images()
{
    // Получаем список категорий для таксономии 'categoria'
    $terms = get_terms(array(
        'taxonomy' => 'categoria',
        'hide_empty' => false, // Показывать и пустые категории
    ));

    // Проверяем, есть ли категории
    if (!empty($terms) && !is_wp_error($terms)) {
        echo '<ul class="categories__list navigation__list">';

        // Цикл по категориям
        foreach ($terms as $term) {
            // Получаем URL изображения для категории
            $image_url = get_term_meta($term->term_id, 'category_image', true);
            // Получаем ссылку на категорию
            $term_link = get_term_link($term);

            // HTML вывод категории с изображением и названием
            echo '<li class="game-category"><a href="' . esc_url($term_link) . '">';
            if ($image_url) {
                echo '<img src="' . esc_url($image_url) . '" alt="' . esc_attr($term->name) . '" />';
            }
            echo '<span>' . esc_html($term->name) . '</span>'; // Название категории
            echo '</a></li>';
        }

        echo '</ul>';
    } else {
        echo '<p>' . _e('No Categories', 'juegos') . '.</p>';
    }
}

?>

<aside class="sidebar">
    <div class="sidebar__top">
        <button class="header__burger burger" id="closeSidebar">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5 12H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M12 5L5 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>
        <div class="header__search search">
            <form class="search__form" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <input class="search__field" type="text" name="s" id="s"
                    placeholder="<?php _e('Search', 'juegos') ?>" />
                <button class="search__submit icon" id="searchButton" type="submit">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M16.5 16.5L12.8807 12.8807M12.8807 12.8807C14.0871 11.6743 14.8333 10.0076 14.8333 8.16667C14.8333 4.48477 11.8486 1.5 8.16667 1.5C4.48477 1.5 1.5 4.48477 1.5 8.16667C1.5 11.8486 4.48477 14.8333 8.16667 14.8333C10.0076 14.8333 11.6743 14.0871 12.8807 12.8807Z"
                            stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </button>
            </form>
        </div>
    </div>
    <nav class="navigation">
        <ul class="navigation__list">
            <?php
            // Получаем текущий полный URL
            $current_url = esc_url((isset($_SERVER['HTTPS']) ? "https://" : "http://") . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);

            // Создаем URL для фильтров
            $new_url = esc_url(add_query_arg('filter', 'new', get_post_type_archive_link('games')));
            $featured_url = esc_url(add_query_arg('filter', 'featured', get_post_type_archive_link('games')));
            $trending_now_url = esc_url(add_query_arg('filter', 'trending-now', get_post_type_archive_link('games')));
            $popular_url = esc_url(add_query_arg('filter', 'popular', get_post_type_archive_link('games')));

            // Универсальная функция для проверки, активна ли ссылка
            function is_active($current_url, $target_url)
            {
                return strpos($current_url, $target_url) === 0;
            }
            ?>

            <li class="menu-item">
                <a class="<?php echo is_front_page() ? 'active' : ''; ?>" href="<?php echo home_url('/'); ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.08337 9.43841C2.08337 8.21422 2.64395 7.05744 3.6048 6.29888L7.52146 3.20677C8.9747 2.05948 11.0254 2.05948 12.4786 3.20677L16.3953 6.29888C17.3561 7.05744 17.9167 8.21422 17.9167 9.43841V13.9167C17.9167 16.1258 16.1258 17.9167 13.9167 17.9167H13.5C12.9478 17.9167 12.5 17.469 12.5 16.9167V14.9167C12.5 13.8121 11.6046 12.9167 10.5 12.9167H9.50004C8.39547 12.9167 7.50004 13.8121 7.50004 14.9167V16.9167C7.50004 17.469 7.05233 17.9167 6.50004 17.9167H6.08337C3.87423 17.9167 2.08337 16.1258 2.08337 13.9167L2.08337 9.43841Z"
                            stroke="#6D49FF" stroke-width="2" />
                    </svg>
                    <span><?php _e('Home', 'juegos'); ?></span>
                </a>
            </li>

            <li class="menu-item">
                <a class="<?php echo is_active($current_url, $new_url) ? 'active' : ''; ?>"
                    href="<?php echo $new_url; ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M10 5.83333V10H14.1667M10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5Z"
                            stroke="white" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <span><?php _e('New Games', 'juegos'); ?></span>
                </a>
            </li>

            <li class="menu-item">
                <a class="<?php echo is_active($current_url, $featured_url) ? 'active' : ''; ?>"
                    href="<?php echo $featured_url; ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9.16667 11.6667H5L7.91667 1.66667H13.3333L10.8333 8.33334H15L8.33333 18.3333L9.16667 11.6667Z"
                            stroke="white" stroke-linejoin="round" />
                    </svg>
                    <span><?php _e('Featured Games', 'juegos'); ?></span>
                </a>
            </li>

            <li class="menu-item">
                <a class="<?php echo is_active($current_url, $trending_now_url) ? 'active' : ''; ?>"
                    href="<?php echo $trending_now_url; ?>">
                    <svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M15.2531 9.67408L14.8865 9.33408L15.2531 9.67408ZM9.36053 3.78153L9.70054 4.14813L9.36053 3.78153ZM18.0509 2.56027L18.5467 2.62511L18.0509 2.56027ZM16.4743 0.983719L16.5392 1.4795L16.4743 0.983719ZM5.41212 9.54217L5.86107 9.76227L5.41212 9.54217ZM9.49245 13.6225L9.27235 13.1736L9.49245 13.6225ZM4.10361 13.6538C4.29888 13.4585 4.29888 13.142 4.10361 12.9467C3.90835 12.7514 3.59177 12.7514 3.39651 12.9467L4.10361 13.6538ZM1.03948 15.3037C0.844223 15.499 0.844223 15.8156 1.03948 16.0108C1.23475 16.2061 1.55133 16.2061 1.74659 16.0108L1.03948 15.3037ZM5.87138 15.4216C6.06664 15.2263 6.06664 14.9097 5.87138 14.7145C5.67612 14.5192 5.35954 14.5192 5.16427 14.7145L5.87138 15.4216ZM3.98576 15.893C3.7905 16.0882 3.7905 16.4048 3.98576 16.6001C4.18102 16.7954 4.49761 16.7954 4.69287 16.6001L3.98576 15.893ZM8.83023 16.5683L9.32521 16.4976L8.83023 16.5683ZM13.1318 13.681L13.6268 13.6103L13.1318 13.681ZM2.46625 10.2044L2.53697 9.70942L2.53697 9.70942L2.46625 10.2044ZM5.35361 5.90283L5.2829 6.39781L5.2829 6.39781L5.35361 5.90283ZM8.03696 12.9467L6.08791 10.9977L5.38081 11.7048L7.32985 13.6538L8.03696 12.9467ZM14.8865 9.33408C13.2915 11.0538 10.7109 12.4683 9.27235 13.1736L9.71254 14.0715C11.1614 13.3611 13.8894 11.8797 15.6197 10.0141L14.8865 9.33408ZM5.86107 9.76227C6.56631 8.32372 7.98086 5.74308 9.70054 4.14813L9.02053 3.41493C7.15492 5.14522 5.67348 7.87318 4.96316 9.32207L5.86107 9.76227ZM17.5551 2.49543C17.3015 4.43452 16.6254 7.45914 14.8865 9.33408L15.6197 10.0141C17.5874 7.89255 18.29 4.58797 18.5467 2.62511L17.5551 2.49543ZM9.70054 4.14813C11.5755 2.40919 14.6001 1.73311 16.5392 1.4795L16.4095 0.487941C14.4466 0.744658 11.1421 1.44727 9.02053 3.41493L9.70054 4.14813ZM18.5467 2.62511C18.7119 1.36162 17.673 0.322693 16.4095 0.487941L16.5392 1.4795C17.1514 1.39943 17.6352 1.88322 17.5551 2.49543L18.5467 2.62511ZM6.08791 10.9977C5.74988 10.6596 5.66248 10.1673 5.86107 9.76227L4.96316 9.32207C4.56466 10.1349 4.7597 11.0837 5.38081 11.7048L6.08791 10.9977ZM7.32985 13.6538C7.95096 14.2749 8.89968 14.47 9.71254 14.0715L9.27235 13.1736C8.86727 13.3721 8.37499 13.2847 8.03696 12.9467L7.32985 13.6538ZM3.39651 12.9467L1.03948 15.3037L1.74659 16.0108L4.10361 13.6538L3.39651 12.9467ZM5.16427 14.7145L3.98576 15.893L4.69287 16.6001L5.87138 15.4216L5.16427 14.7145ZM11.0694 4.90108C10.2233 5.74722 10.2233 7.11907 11.0694 7.96521L11.7765 7.2581C11.3209 6.80249 11.3209 6.0638 11.7765 5.60819L11.0694 4.90108ZM11.0694 7.96521C11.9155 8.81134 13.2874 8.81134 14.1335 7.96521L13.4264 7.2581C12.9708 7.71371 12.2321 7.71371 11.7765 7.2581L11.0694 7.96521ZM14.1335 7.96521C14.9797 7.11907 14.9797 5.74722 14.1335 4.90108L13.4264 5.60819C13.882 6.0638 13.882 6.80249 13.4264 7.2581L14.1335 7.96521ZM14.1335 4.90108C13.2874 4.05494 11.9155 4.05494 11.0694 4.90108L11.7765 5.60819C12.2321 5.15257 12.9708 5.15257 13.4264 5.60819L14.1335 4.90108ZM12.5425 14.0345L9.89089 16.6862L10.598 17.3933L13.2497 14.7416L12.5425 14.0345ZM9.32521 16.4976L8.97165 14.0228L7.9817 14.1642L8.33526 16.6391L9.32521 16.4976ZM12.4011 12.1018L12.6368 13.7517L13.6268 13.6103L13.3911 11.9604L12.4011 12.1018ZM9.89089 16.6862C9.69666 16.8804 9.36405 16.7696 9.32521 16.4976L8.33526 16.6391C8.49064 17.7267 9.82108 18.1702 10.598 17.3933L9.89089 16.6862ZM13.2497 14.7416C13.5464 14.4449 13.6861 14.0257 13.6268 13.6103L12.6368 13.7517C12.6517 13.8556 12.6167 13.9604 12.5425 14.0345L13.2497 14.7416ZM4.29295 5.78498L1.6413 8.43663L2.3484 9.14374L5.00005 6.49209L4.29295 5.78498ZM2.39554 10.6994L4.87042 11.0529L5.01184 10.063L2.53697 9.70942L2.39554 10.6994ZM7.07423 5.64356L5.42432 5.40786L5.2829 6.39781L6.93281 6.63351L7.07423 5.64356ZM1.6413 8.43663C0.864378 9.21355 1.30786 10.544 2.39554 10.6994L2.53697 9.70942C2.26504 9.67058 2.15417 9.33797 2.3484 9.14374L1.6413 8.43663ZM5.00005 6.49209C5.07424 6.4179 5.17903 6.38297 5.2829 6.39781L5.42432 5.40786C5.00886 5.34851 4.5897 5.48822 4.29295 5.78498L5.00005 6.49209Z"
                            fill="white" />
                    </svg>
                    <span><?php _e('Trending now', 'juegos'); ?></span>
                </a>
            </li>

            <li class="menu-item">
                <a class="<?php echo is_active($current_url, $popular_url) ? 'active' : ''; ?>"
                    href="<?php echo $popular_url; ?>">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_95_1573)">
                            <path
                                d="M17.3604 20H6C4.89543 20 4 19.1046 4 18V10H7.92963C8.59834 10 9.2228 9.6658 9.59373 9.1094L12.1094 5.3359C12.6658 4.5013 13.6025 4 14.6056 4H14.8195C15.4375 4 15.9075 4.55487 15.8059 5.1644L15 10H18.5604C19.8225 10 20.7691 11.1547 20.5216 12.3922L19.3216 18.3922C19.1346 19.3271 18.3138 20 17.3604 20Z"
                                stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M8 10V20" stroke="white" stroke-width="2" />
                        </g>
                        <defs>
                            <clipPath id="clip0_95_1573">
                                <rect width="24" height="24" fill="white" />
                            </clipPath>
                        </defs>
                    </svg>

                    <span><?php _e('Popular Games', 'juegos'); ?></span>
                </a>
            </li>

            <li class="menu-item categories">
                <a href="#">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="2.91663" y="3.33334" width="5.83333" height="3.33333" rx="1.66667" stroke="white" />
                        <rect x="2.91663" y="9.16669" width="5.83333" height="8.33333" rx="2.5" stroke="white" />
                        <rect x="11.25" y="3.33334" width="5.83333" height="8.33333" rx="2.5" stroke="white" />
                        <rect x="11.25" y="14.1667" width="5.83333" height="3.33333" rx="1.66667" stroke="white" />
                    </svg>
                    <span><?php _e('Categories', 'juegos'); ?></span>
                </a>
            </li>
        </ul>
        <?php display_game_categories_with_images(); ?>

    </nav>
    <footer class="footer">
        <nav class="footer__nav">
            <?php
            $menu = wp_nav_menu([
                'theme_location' => 'footer-menu',
                'container' => 'ul',
                'menu_class' => 'footer__nav-list',
            ]);
            if ($menu) {
                echo $menu;
            }
            ?>
        </nav>
        <p class="copy">©<?php echo date('Y'); ?>. <?php echo get_bloginfo('name'); ?></p>
    </footer>
</aside>